// -*- coding: utf-8 -*-
// Controla o leitor de capítulo: modo de leitura (rolagem contínua ou
// página a página), zoom, atalhos de teclado e zonas de clique/toque
// pra virar página. Preferências ficam salvas no navegador (localStorage)
// pra manter a escolha do leitor entre capítulos.
(function () {
  const root = document.getElementById("readerRoot");
  if (!root) return;

  const mangaSlug = root.dataset.mangaSlug;
  const prevChapter = root.dataset.prev || null;
  const nextChapter = root.dataset.next || null;

  const pagesContainer = document.getElementById("readerPages");
  const images = Array.from(document.querySelectorAll(".page-img"));
  const totalPages = images.length;

  const modeBtn = document.getElementById("modeToggleBtn");
  const zoomInBtn = document.getElementById("zoomInBtn");
  const zoomOutBtn = document.getElementById("zoomOutBtn");
  const zoomLabel = document.getElementById("zoomLabel");
  const pageCounter = document.getElementById("pageCounter");
  const zones = document.getElementById("readerZones");

  const STORAGE_MODE = "reader:mode";
  const STORAGE_ZOOM = "reader:zoom";

  let mode = localStorage.getItem(STORAGE_MODE) || "scroll"; // "scroll" | "page"
  let zoom = parseInt(localStorage.getItem(STORAGE_ZOOM) || "100", 10);
  let currentPage = 0;

  function clampZoom(z) { return Math.max(50, Math.min(200, z)); }

  function applyZoom() {
    zoom = clampZoom(zoom);
    localStorage.setItem(STORAGE_ZOOM, String(zoom));
    zoomLabel.textContent = zoom + "%";
    const widthPx = Math.round(720 * (zoom / 100));
    images.forEach(img => { img.style.maxWidth = widthPx + "px"; });
    // Se ampliado além de 100%, permite rolagem horizontal no modo página
    pagesContainer.style.overflowX = zoom > 100 ? "auto" : "visible";
  }

  function goToChapter(number) {
    if (number === null || number === undefined || number === "") return;
    window.location.href = `/manga/${mangaSlug}/chapter/${number}`;
  }

  function updatePageVisibility() {
    images.forEach((img, i) => { img.style.display = i === currentPage ? "block" : "none"; });
    pageCounter.textContent = `${currentPage + 1} / ${totalPages}`;
    // Rola pro topo ao trocar de página, pra sempre começar vendo o quadro inteiro
    window.scrollTo({ top: pagesContainer.offsetTop - 70, behavior: "instant" in window ? "instant" : "auto" });
  }

  function applyMode() {
    localStorage.setItem(STORAGE_MODE, mode);
    if (mode === "page") {
      pagesContainer.classList.add("mode-page");
      modeBtn.textContent = "Página";
      pageCounter.classList.remove("hidden");
      zones.classList.remove("hidden");
      currentPage = Math.min(currentPage, totalPages - 1);
      updatePageVisibility();
    } else {
      pagesContainer.classList.remove("mode-page");
      modeBtn.textContent = "Rolagem";
      pageCounter.classList.add("hidden");
      zones.classList.add("hidden");
      images.forEach(img => { img.style.display = "block"; });
    }
  }

  function nextPage() {
    if (mode !== "page") { window.scrollBy({ top: window.innerHeight * 0.85, behavior: "smooth" }); return; }
    if (currentPage < totalPages - 1) { currentPage += 1; updatePageVisibility(); }
    else if (nextChapter) { goToChapter(nextChapter); }
  }
  function prevPage() {
    if (mode !== "page") { window.scrollBy({ top: -window.innerHeight * 0.85, behavior: "smooth" }); return; }
    if (currentPage > 0) { currentPage -= 1; updatePageVisibility(); }
    else if (prevChapter) { goToChapter(prevChapter); }
  }

  modeBtn.addEventListener("click", () => {
    mode = mode === "scroll" ? "page" : "scroll";
    applyMode();
  });
  zoomInBtn.addEventListener("click", () => { zoom += 10; applyZoom(); });
  zoomOutBtn.addEventListener("click", () => { zoom -= 10; applyZoom(); });

  zones.querySelector(".zone-left").addEventListener("click", prevPage);
  zones.querySelector(".zone-right").addEventListener("click", nextPage);

  window.addEventListener("keydown", (e) => {
    if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
    switch (e.key) {
      case "ArrowRight": case "d": case "D": nextPage(); break;
      case "ArrowLeft": case "a": case "A": prevPage(); break;
      case "m": case "M": mode = mode === "scroll" ? "page" : "scroll"; applyMode(); break;
      case "+": case "=": zoom += 10; applyZoom(); break;
      case "-": case "_": zoom -= 10; applyZoom(); break;
      default: return;
    }
    e.preventDefault();
  });

  applyZoom();
  applyMode();
})();
